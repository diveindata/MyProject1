import tensorflow as tf
from tensorflow.keras import datasets, layers, models
import numpy as np

# Load the CIFAR-10 dataset
(X, Y), (X1, Y1) = datasets.cifar10.load_data()#train X,Y and test X1,Y1
Y = Y.reshape(-1)
Y1 = Y1.reshape(-1)

X = X.astype('float32') / 255.0#Normalize pixel
X1 = X1.astype('float32') / 255.0

m = models.Sequential() # Define the CNN Model
# Convolutional Block 1
m.add(layers.Conv2D(32, (3, 3), activation='relu', input_shape=(32, 32, 3)))
m.add(layers.Conv2D(32, (3, 3), activation='relu'))
m.add(layers.MaxPooling2D((2, 2)))
m.add(layers.Dropout(0.25))

# Convolutional Block 2
m.add(layers.Conv2D(64, (3, 3), activation='relu'))
m.add(layers.Conv2D(64, (3, 3), activation='relu'))
m.add(layers.MaxPooling2D((2, 2)))
m.add(layers.Dropout(0.25))
m.add(layers.Flatten()) # Fully Connected Layers
m.add(layers.Dense(512, activation='relu'))
m.add(layers.Dropout(0.5))
m.add(layers.Dense(10, activation='softmax'))

m.compile(optimizer='adam',loss='sparse_categorical_crossentropy',
metrics=['accuracy'])# Compile the Model

history = m.fit(X, Y,epochs=10,batch_size=64,validation_data=(X1, Y1))#train

test_loss, test_accuracy = m.evaluate(X1, Y1, verbose=2)# Evaluate the Model
print(f"Test Loss: {test_loss}")
print(f"Test Accuracy: {test_accuracy}")


