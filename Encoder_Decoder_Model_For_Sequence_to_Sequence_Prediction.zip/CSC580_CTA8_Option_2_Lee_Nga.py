
import numpy as np
from numpy import array, argmax, array_equal
from numpy.random import randint
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, LSTM, Dense
from keras.optimizers import Adam
def generate_sequence(length,n_unique): # generate sequence
    return [randint(1, n_unique)for _ in range(length)]
def one_hot_decode(encoded_seq): # convert to a vector
    return [argmax(vector) for vector in encoded_seq]
# data processing
def get_dataset(n_in,n_out,cardinality,n_samples):
    X1, X2, y = list(), list(),list()
    for _ in range(n_samples):
        source = generate_sequence(n_in, cardinality-1)#source sequence
        target = source[:n_out]# target sequence
        target.reverse()
        target_in = [0] + target[:-1]
        src_encoded = to_categorical([source], num_classes=cardinality)#alphabet size
        tar_encoded = to_categorical([target], num_classes=cardinality)
        tar2_encoded = to_categorical([target_in], num_classes=cardinality)
        X1.append(src_encoded)
        X2.append(tar2_encoded)
        y.append(tar_encoded)
    X1 = np.array(X1)#encoder
    X2 = np.array(X2)#decoder
    y = np.array(y)#decoder output
    return X1, X2, y

def define_models(n_input, n_output, n_units):
    encoder_inputs = Input(shape=(None, n_input))#unspecified length
    encoder = LSTM(n_units, return_state=True)
    encoder_outputs, state_h, state_c = encoder(encoder_inputs)
    encoder_states = [state_h, state_c]

    decoder_inputs = Input(shape=(None, n_output))#each timestep had output values
    decoder_lstm = LSTM(n_units, return_sequences=True, return_state=True)#continuity btw encoder and decoder
    decoder_outputs, _, _ = decoder_lstm(decoder_inputs, initial_state=encoder_states)
    decoder_dense = Dense(n_output, activation='softmax')#lstm outputs to probability distrbution
    decoder_outputs = decoder_dense(decoder_outputs)
    model = Model([encoder_inputs, decoder_inputs], decoder_outputs)#combine as model
    encoder_model = Model(encoder_inputs, encoder_states)#sequence to hidden states
    decoder_state_input_h = Input(shape=(n_units,))
    decoder_state_input_c = Input(shape=(n_units,))
    decoder_states_inputs = [decoder_state_input_h, decoder_state_input_c]
    decoder_inf_outputs, state_h_inf, state_c_inf = decoder_lstm(
        decoder_inputs, initial_state=decoder_states_inputs)
    decoder_states = [state_h_inf, state_c_inf]
    decoder_inf_outputs = decoder_dense(decoder_inf_outputs)
    decoder_model = Model(#took previous token and encoder to next output toekn
        [decoder_inputs] + decoder_states_inputs,
        [decoder_inf_outputs] + decoder_states)
    return model, encoder_model, decoder_model
def predict_sequence(infenc, infdec, source, n_steps, cardinality):
    state = infenc.predict(source, verbose=0)#encode
    target_seq = array([0.0 for _ in range(cardinality)]).reshape(1, 1, cardinality)# start sequence input
    output = []#collect predictions
    for _ in range(n_steps):
        yhat, h, c = infdec.predict([target_seq] + state, verbose=0)#predict next char
        output.append(yhat[0, 0, :])#store prediction
        state = [h, c]#update state
        target_seq = yhat # update target sequence
    return np.array(output)
#save predictions to file
def predictions_file(predictions, filename="predictions_output.txt"):
    with open(filename, "w") as file:
        for prediction in predictions:
            file.write(f"{prediction}\n")
n_features = 50 + 1
n_steps_in = 6
n_steps_out = 3
n_units = 128
#define and compile model
train_model, infenc_model, infdec_model = define_models(n_features, n_features, n_units)
optimizer = Adam(clipnorm=1.0)
train_model.compile(optimizer=optimizer, loss='categorical_crossentropy', metrics=['accuracy'])

print("Generating training dataset...")
X1train, X2train, ytrain = get_dataset(n_steps_in, n_steps_out, n_features, n_samples=10000)
print(f"Training shapes: X1={X1train.shape}, X2={X2train.shape}, y={ytrain.shape}")

print("Training encoder-decoder model...")
train_model.fit(
    [X1train.reshape((10000, n_steps_in, n_features)),
     X2train.reshape((10000, n_steps_out, n_features))],
    ytrain.reshape((10000, n_steps_out, n_features)),
    epochs=100,
    batch_size=64,
    verbose=2
)

total = 100
correct = 0
print("\nEvaluating model accuracy on 100 random samples...")
for _ in range(total):
    X1test, X2test, ytest = get_dataset(n_steps_in, n_steps_out, n_features, 1)
    yhat = predict_sequence(infenc_model, infdec_model,
                            X1test.reshape((1, n_steps_in, n_features)),
                            n_steps_out, n_features)

    if array_equal(one_hot_decode(ytest[0]), one_hot_decode(yhat)):
        correct += 1
predictions = []
print(f"Accuracy on 100 random samples: {correct/total*100:.2f}%")

print("\nSample predictions:")
for _ in range(10):
    X1test, X2test, ytest = get_dataset(n_steps_in, n_steps_out, n_features, 1)
    source_seq = one_hot_decode(X1test[0])
    expected_seq = one_hot_decode(ytest[0])
    prediction = predict_sequence(infenc_model, infdec_model,
                                  X1test.reshape((1, n_steps_in, n_features)),
                                  n_steps_out, n_features)
    predicted_seq = one_hot_decode(prediction)
    print(f"Source={source_seq}  Expected={expected_seq},  Predicted={predicted_seq}")
    predictions.append(f"Source={source_seq}  Expected={expected_seq},  Predicted={predicted_seq}")

predictions_file(predictions)