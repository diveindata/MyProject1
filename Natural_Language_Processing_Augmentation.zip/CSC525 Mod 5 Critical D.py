import os # don't use
import random
from nltk.corpus import wordnet
from nltk.tokenize import word_tokenize
import nltk

# Download necessary NLTK resources
nltk.download('punkt')
nltk.download('wordnet')


# Function to replace words with their synonyms
def replace_synonyms(text):
    words = word_tokenize(text)
    return ' '.join([get_synonym(word) for word in words])


def get_synonym(word):
    synonyms = wordnet.synsets(word)
    if synonyms and random.random() < 0.3:  # Replace with synonym 30% of the time
        return random.choice(synonyms).lemmas()[0].name()
    return word


# Load and augment dataset
def augment_dataset():
    # Loop through all .txt files in the current directory
    for filename in os.listdir():
        if filename.endswith("CSC525_Unaugmented_dataset.txt"):  # Only process .txt files
            with open(filename, "r", encoding="utf-8") as f:
                content = f.read()

            # Augment the content by replacing synonyms
            augmented_content = replace_synonyms(content)

            # Write the augmented content to a new file
            new_filename = "augmented_testing"
            with open(new_filename, "w", encoding="utf-8") as f:
                f.write(augmented_content)
            print(f"Augmented file saved as: {new_filename}")


if __name__ == "__main__":
    augment_dataset()
