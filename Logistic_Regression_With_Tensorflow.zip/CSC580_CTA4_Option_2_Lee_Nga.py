import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf

N = 100 # Generate synthetic data

# Zeros form a Gaussian centered at (-1, -1)
x_zeros = np.random.multivariate_normal(
    mean=np.array((-1, -1)), cov=.1 * np.eye(2), size=(N // 2,))
y_zeros = np.zeros((N // 2,))
# Ones form a Gaussian centered at (1, 1)
x_ones = np.random.multivariate_normal(
    mean=np.array((1, 1)), cov=.1 * np.eye(2), size=(N // 2,))
y_ones = np.ones((N // 2,))
x_np = np.vstack([x_zeros, x_ones])
y_np = np.concatenate([y_zeros, y_ones])

#Plot x_zeros and x_ones on the same graph.
color = ['blue', "red"]
labels = ['zeros','ones']

for a,c,l in zip ([x_zeros,x_ones],color,labels):
    plt.scatter(a[:,0],a[:,1],color=c, label=l)

plt.xlabel('x_zeros')
plt.ylabel('x_ones')
plt.title('Given Data Mod 4 Nga Lee')
plt.legend()
plt.show()
# using Keras API for the model.
keraapi = tf.keras.Sequential([
    tf.keras.layers.Dense(1, activation='sigmoid', input_shape=(2,))
])
# Compile the model
keraapi.compile(
    optimizer=tf.keras.optimizers.Adam(learning_rate=0.01),
    loss=tf.keras.losses.BinaryCrossentropy(),
    metrics=['accuracy'])
# Train the model
history = keraapi.fit(x_np, y_np, epochs=100, batch_size=10, verbose=1)
y_pred = (keraapi.predict(x_np) > 0.5).astype(int)# Get predictions

# Plot predictions
x1,y1 = np.meshgrid(np.linspace(x_np[:,0].min()-1,x_np[:,0].max()+1,100),#plot x and y axis
                    np.linspace(x_np[:,1].min()-1,x_np[:,1].max()+1,100))
a1 = np.c_[x1.ravel(), y1.ravel()]#flatten grid
a2 = keraapi.predict(a1).reshape(x1.shape)#plot the prediction
plt.contourf(x1, y1, a2, levels=[0, 0.5, 1], alpha=0.2, colors=['blue', 'red'])
plt.scatter(x_np[:, 0], x_np[:, 1], c=y_np , cmap='bwr')
plt.title("Predicted Outputs for Logistic Regression")
plt.show()
