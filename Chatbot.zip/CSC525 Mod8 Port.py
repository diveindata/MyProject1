from chatterbot import ChatBot #working csc525
from chatterbot.trainers import ChatterBotCorpusTrainer
import spacy
cb = ChatBot('CSC525_Movies_ChatBot =)')# chatbot name
model = spacy.load('en_core_web_sm') # Initialize spaCy model
cbtrain = ChatterBotCorpusTrainer(cb) # Train with English corpus
cbtrain.train('chatterbot.corpus.english')
cbtrain.train('chatterbot.corpus.english.greetings')
def chatbot(i): # user input
    doc = model(i) # Process the input using spaCy
    convo = cb.get_response(i) # Get chatbot response
    if not convo:
        return "I don't have an answer for that."
    return convo
print("Chat with the coolest CSC525 movies chatbot (type 'exit' or 'quit' to stop)")
while True: #conversation btw you and bot
    i = input("You: ")
    if i.lower() in ["exit", "quit"]:
        print("Have a good day. Goodbye!")
        break
    convo = chatbot(i)
    print(f"MoviesBot: {convo}")

