from sklearn.datasets import load_iris
from sklearn.ensemble import RandomForestClassifier
import pandas as pd
import numpy as np

np.random.seed(0)#set random seed
iris = load_iris()#create object
df = pd.DataFrame(iris.data,columns=iris.feature_names)#create dataframe
#new column with species name for prediction
df['species'] = pd.Categorical.from_codes(iris.target,iris.target_names)

print("Head of the dataset:")
print(df.head())#view the top 5 rows

#create training and test data
df['is_train'] = np.random.uniform(0, 1, len(df)) <= 0.75

print("\nTop 5 rows with 'is_train' column:")#view top 5 rows
print(df.head())

train = df[df['is_train'] == True]
test  = df[df['is_train'] == False]

print("\nNumber of observations in the training data:", len(train))
print("Number of observations in the test data:", len(test))

# preprocess the data
features = df.columns[:4] #create list of the feature column's name
print("\nFeature columns:", list(features))

y = pd.factorize(train['species'])[0] #convert name into a digit
print("Numeric conversion of species in training set:", y)

#train the random forest classifier
clf = RandomForestClassifier(n_estimators=10, n_jobs=2, random_state=0)
clf.fit(train[features], y)#train the classifier to take the training features

print("\nTrained RandomForestClassifier:")
print(clf)

#apply classifier to the test data and make prediction probabilities
preds = clf.predict(test[features])

probs = clf.predict_proba(test[features])
print("\nPredicted probabilities (first 10 observations):")
print(probs[:10])

# Evaluate predicted vs actual species for the first 5
print("\nFirst 5 test predictions vs actual species:")
print("Predicted:", preds[:5])
print("Actual:   ", test['species'].values[:5])

# confusion matrix to interpret classification method
confusion_matrix = pd.crosstab(test['species'],preds,
rownames=['Actual Species'], colnames=['Predicted Species'])
print("\nConfusion Matrix:")
print(confusion_matrix)

print("\nFeature importances:") # view the list of features and their scores
for feature_name, importance_score in zip(features, clf.feature_importances_):
    print(feature_name, "=", importance_score)
