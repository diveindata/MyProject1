import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

data_url = "http://lib.stat.cmu.edu/datasets/boston" #load data per error message
raw_df = pd.read_csv(data_url, sep="\s+", skiprows=22, header=None)
data = np.hstack([raw_df.values[::2, :], raw_df.values[1::2, :2]])
target = raw_df.values[1::2, 2]
#training and testing
X_train, x_test, Y_train, y_test = train_test_split(data, target, test_size=0.2, random_state=42)

LR = LinearRegression()#linear Regresion model
LR.fit(X_train, Y_train)

train = LR.predict(x_test)
train1=train*1000# Make predictions in thousand dollars
test = y_test*1000

print(f"Predicted House Price: $ {train1[0]:.2f}")
print(f"Actual House price: $ {test[0]:.2f}")
mean_squared = mean_squared_error(y_test, train)
r2 = r2_score(y_test, train)
print(f"\nMean Squared Error: {mean_squared}")
print(f"R-squared: {r2}")

