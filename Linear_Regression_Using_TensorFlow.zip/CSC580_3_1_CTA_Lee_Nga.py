import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
from tensorflow.keras.optimizers import SGD

np.random.seed(101)
tf.random.set_seed(101) # reproducibility
x = np.linspace(0, 50, 50)
y = np.linspace(0, 50, 50)
x += np.random.uniform(-4, 4, 50) # noise
y += np.random.uniform(-4, 4, 50)

n = len(x)  # Number of data points
plt.scatter(x, y) # plot the training data
plt.xlabel('x')
plt.ylabel('y')
plt.title("Training Data Mod 3 Nga Lee")
plt.show()

x = (x - np.mean(x)) / np.std(x) #normalize by applying mean and deviation
y = (y - np.mean(y)) / np.std(y)

# declare two trainable tensorflow variables weights and bias
weight=tf.Variable(np.random.randn())
bias=tf.Variable(np.random.randn())

learning_rate = 0.01# hyperparameters
training_epochs = 1000

optimizer = tf.keras.optimizers.SGD(learning_rate=learning_rate)

# training process
for epoch in range (1000):
    with tf.GradientTape() as tape:
        hyp = weight * x + bias
        cost = tf.reduce_mean(tf.square(hyp - y))

    grads = tape.gradient(cost, [weight, bias])
    if None not in grads: # if the gradients are valid
        optimizer.apply_gradients(zip(grads, [weight, bias]))
    if (epoch)%100==0:
        print(f"Epoch {epoch}, Cost: {cost.numpy()}, W: {weight.numpy()}, b: {bias.numpy()}")

predictions=weight.numpy()*x+bias.numpy() # print training cost, weight and bias
print("Training cost=", cost.numpy(), "weight= ", weight.numpy(), 'bias=', bias.numpy)

# plot fitted line on original data
plt.scatter(x, y, label="Training Data")
plt.plot(x, predictions, color='red', label="Fitted Line")
plt.xlabel("X")
plt.ylabel("Y")
plt.legend()
plt.show()

