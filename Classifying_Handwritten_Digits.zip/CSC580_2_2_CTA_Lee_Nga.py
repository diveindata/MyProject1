import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from keras.models import Sequential
from keras.layers import Dense
from keras.models import load_model

training = pd.read_csv("sales_data_training.csv") # load training data
testing = pd.read_csv("sales_data_test.csv") # load testing data

scaler = MinMaxScaler(feature_range=(0, 1)) # minmaxscaler range 0 to 1

scaled_training = scaler.fit_transform(training) # scale training and testing data
scaled_testing = scaler.transform(testing)

print(
    "Note: total_earnings values were scaled by multiplying by {:.10f} and adding {:.6f}".format(
        scaler.scale_[8], scaler.min_[8]
    )
)

scaled_training_df = pd.DataFrame(scaled_training, columns=training.columns.values) # panda dataframe
scaled_testing_df = pd.DataFrame(scaled_testing, columns=testing.columns.values)

scaled_training_df.to_csv("sales_data_training_scaled.csv", index=False) # save the scaled data
scaled_testing_df.to_csv("sales_data_testing_scaled.csv", index=False)
training_data_df = pd.read_csv("sales_data_training_scaled.csv")

X = training_data_df.drop('total_earnings', axis=1).values  # split input x
Y = training_data_df[['total_earnings']].values  # split output y

model = Sequential([ # define model
    Dense(50, input_dim=9, activation='relu'),  #  hidden layer
    Dense(1, activation='linear')              # Output layer
])
model.compile(optimizer='sgd', loss='mean_squared_error')
model.fit(X, Y, epochs=50, shuffle=True, verbose=2)# Train the model
model.save("trained_model.keras")
print("Model saved to disk.")
test_data_df = pd.read_csv("sales_data_test_scaled.csv")

X_test = test_data_df.drop('total_earnings', axis=1).values # evaluate the model nad split test data
Y_test = test_data_df[['total_earnings']].values

test_error_rate = model.evaluate(X_test, Y_test, verbose=2) #
print("The mean squared error (MSE) for the test data set is: {:.6f}".format(test_error_rate))

model = load_model("trained_model.keras")
X = pd.read_csv("proposed_new_product.csv").values
prediction = model.predict(X)[0][0]

rescaled = 1 / scaler.scale_[8]  # Rescale data
inverse = -scaler.min_[8] / scaler.scale_[8]

prediction = prediction * rescaled + inverse
print("Earnings Prediction for Proposed Product: ${:.2f}".format(prediction))



